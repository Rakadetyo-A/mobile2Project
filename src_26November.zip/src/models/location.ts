export class Loc {
  constructor (public lat: number, public lng: number) {}
}
