import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Loc } from '../../models/location'
import { Config } from 'ionic-angular/config/config';
import { ModalController } from 'ionic-angular/components/modal/modal-controller';

import { RegisterEventPage } from '../register-event/register-event';
/**
 * Generated class for the MapsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-maps',
  templateUrl: 'maps.html',
})
export class MapsPage {
  location : Loc;
  lat = -6.178306;
  lng = 106.631889;

  constructor(public navCtrl: NavController, public navParams: NavParams, public config: Config, public modalCtrl: ModalController) 
  {
    this.location = new Loc(this.lat, this.lng);
    this.config.set('tabsPlacement', 'top');
  }

  onSetMarker(event: any) 
  {
    this.location = new Loc(event.coords.lat, event.coords.lng);
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad MapsPage');
  }

  showModal() {
    let modal = this.modalCtrl.create(RegisterEventPage);
    modal.present();
    // modal.onDidDismiss((remove: boolean) => {
    //   if (remove) {
    //     this.quoteService.removeQuoteFromFavorites(quote);
    //     this.quotes = this.quoteService.getFavoriteQuotes();
    //   }
    // })
  }

}
